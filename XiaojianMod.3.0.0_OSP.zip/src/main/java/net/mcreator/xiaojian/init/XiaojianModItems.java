/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.xiaojian.init;

import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.client.renderer.item.ClampedItemPropertyFunction;

import net.mcreator.xiaojian.item.LollipopItem;
import net.mcreator.xiaojian.XiaojianMod;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

public class XiaojianModItems {
	public static Item LOLLIPOP;
	public static Item XIAOJIAN_SPAWN_EGG;

	public static void load() {
		LOLLIPOP = register("lollipop", new LollipopItem());
		XIAOJIAN_SPAWN_EGG = register("xiaojian_spawn_egg", new SpawnEggItem(XiaojianModEntities.XIAOJIAN, -1, -1, new Item.Properties()));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.SPAWN_EGGS).register(content -> content.accept(XIAOJIAN_SPAWN_EGG));
	}

	public static void clientLoad() {
	}

	private static Item register(String registryName, Item item) {
		return Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(XiaojianMod.MODID, registryName), item);
	}

	private static void registerBlockingProperty(Item item) {
		ItemProperties.register(item, new ResourceLocation("blocking"), (ClampedItemPropertyFunction) ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
	}
}
