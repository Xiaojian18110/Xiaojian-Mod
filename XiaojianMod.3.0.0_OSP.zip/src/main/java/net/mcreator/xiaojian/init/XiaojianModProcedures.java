
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.xiaojian.init;

import net.mcreator.xiaojian.procedures.XiaojianEntityIsHurtProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class XiaojianModProcedures {
	public static void load() {
		new XiaojianEntityIsHurtProcedure();
	}
}
